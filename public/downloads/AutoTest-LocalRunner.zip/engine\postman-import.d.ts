import type { ApiAssertion, KeyValueItem } from "./api-test-runner.js";
export interface ImportedPostmanCase {
    name: string;
    description: string;
    method: string;
    url: string;
    headers: KeyValueItem[];
    queryParams: KeyValueItem[];
    bodyType: "none" | "json" | "text" | "form";
    body: string;
    assertions: ApiAssertion[];
    variables: Record<string, string>;
    environmentId: string;
    group: string;
}
export interface PostmanImportResult {
    collectionName: string;
    cases: ImportedPostmanCase[];
    skipped: number;
    warnings: string[];
}
export declare function parsePostmanCollection(collection: any): PostmanImportResult;
