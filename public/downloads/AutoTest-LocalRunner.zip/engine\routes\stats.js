import { Router } from "express";
import { all, query } from "../data/db.js";
const router = Router();
// GET /api/stats — Dashboard 统计数据
router.get("/", (_req, res) => {
    const casesData = all("cases");
    const elementsData = all("elements");
    const environmentsData = all("environments");
    const alertsData = all("alerts");
    const totalCases = casesData.length;
    const activeCases = casesData.filter((c) => c.status === "active").length;
    const recentExecs = query(`SELECT * FROM executions WHERE start_time IS NOT NULL ORDER BY start_time DESC LIMIT 20`);
    const passed = recentExecs.filter((e) => e.status === "success").length;
    const failed = recentExecs.filter((e) => e.status === "failed").length;
    const passRate = recentExecs.length > 0 ? Math.round((passed / recentExecs.length) * 100) : 0;
    const today = new Date().toISOString().slice(0, 10);
    const todayExecs = query(`SELECT COUNT(*) as c FROM executions WHERE start_time LIKE ?`, `${today}%`);
    // 近 7 天趋势
    const trends = [];
    for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const ds = d.toISOString().slice(0, 10);
        const dayExecs = query(`SELECT status, COUNT(*) as c FROM executions WHERE start_time LIKE ? GROUP BY status`, `${ds}%`);
        const total = dayExecs.reduce((s, r) => s + Number(r.c || 0), 0);
        const findStatus = (status) => dayExecs.find((r) => r.status === status);
        const dayPassed = Number(findStatus("success")?.c) || 0;
        const dayFailed = Number(findStatus("failed")?.c) || 0;
        trends.push({ date: ds.slice(5), total, passed: dayPassed, failed: dayFailed });
    }
    res.json({
        totalCases,
        activeCases,
        totalExecutions: query(`SELECT COUNT(*) as c FROM executions`)[0]?.c,
        todayExecutions: todayExecs[0]?.c || 0,
        passRate,
        totalElements: elementsData.length,
        totalEnvironments: environmentsData.length,
        totalAlerts: alertsData.filter((a) => a.enabled).length,
        recentExecutions: recentExecs.slice(0, 8).map((e) => ({
            id: e.id,
            caseId: e.case_id,
            caseName: e.case_name,
            status: e.status,
            startTime: e.start_time,
            endTime: e.end_time,
            duration: e.duration,
        })),
        trends,
    });
});
export default router;
//# sourceMappingURL=stats.js.map