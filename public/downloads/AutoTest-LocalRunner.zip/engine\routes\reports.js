import { Router } from "express";
import { get, query } from "../data/db.js";
import { safeLimit, safePage } from "../paging.js";
const router = Router();
function toApi(row) {
    return {
        ...row,
        executionId: row.execution_id,
        caseId: row.case_id,
        caseName: row.case_name,
        startTime: row.start_time,
        endTime: row.end_time,
        errorMessage: row.error_message,
        createdAt: row.created_at,
    };
}
// GET /api/reports
router.get("/", (req, res) => {
    const { status, caseId, page = "1", limit = "20" } = req.query;
    let list = query(`SELECT * FROM reports ORDER BY created_at DESC`);
    if (status)
        list = list.filter((r) => r.status === status);
    if (caseId)
        list = list.filter((r) => r.case_id === caseId);
    const p = safePage(page, 1);
    const l = safeLimit(limit, 20);
    const total = list.length;
    const items = list.slice((p - 1) * l, p * l).map(toApi);
    res.json({ items, total, page: p, limit: l });
});
// GET /api/reports/:id
router.get("/:id", (req, res) => {
    const item = get("reports", req.params.id);
    if (!item) {
        res.status(404).json({ error: "not found" });
        return;
    }
    res.json(toApi(item));
});
export default router;
//# sourceMappingURL=reports.js.map