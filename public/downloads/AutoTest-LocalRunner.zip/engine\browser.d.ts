import { Browser } from "playwright";
import type { AutoDetectSession, DetectedElement } from "./types.js";
export declare function getBrowser(headless: boolean): Promise<Browser>;
export declare function openPage(url: string, headless: boolean, apiBaseUrl: string): Promise<{
    sessionId: string;
}>;
export declare function scanPageElements(sessionId: string): Promise<{
    elements: DetectedElement[];
    totalFound: number;
    afterDedup: number;
}>;
export declare function receiveReport(sessionId: string, rawElements: DetectedElement[]): {
    elements: DetectedElement[];
    totalFound: number;
    afterDedup: number;
};
export declare function closePage(sessionId: string): Promise<void>;
export declare function getSession(sessionId: string): AutoDetectSession | undefined;
export declare function getSessionElements(sessionId: string): DetectedElement[];
