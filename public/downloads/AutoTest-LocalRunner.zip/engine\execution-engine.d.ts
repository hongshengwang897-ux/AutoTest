export interface ExecutionResult {
    status: "pass" | "fail";
    logs: {
        timestamp: string;
        level: "info" | "warn" | "error";
        message: string;
    }[];
    duration: number;
    error?: string;
    steps: {
        id: string;
        action: string;
        selector: string;
        status: string;
        duration: number;
    }[];
    screenshot?: string;
}
export interface ExecutionOptions {
    timeoutMs?: number;
    screenshotOnFailure?: boolean;
    visualBaselines?: Record<string, VisualBaseline>;
}
export interface VisualBaseline {
    image: string;
    similarityThreshold: number;
}
/**
 * 包装用户脚本为可执行函数体
 * 去掉 import 声明、test() 包装，只保留测试步骤
 */
export declare function wrapScript(script: string): string;
/**
 * 执行用例脚本并返回结果
 */
export declare function executeCase(script: string, scriptName?: string, baseUrl?: string, signal?: AbortSignal, options?: ExecutionOptions): Promise<ExecutionResult>;
