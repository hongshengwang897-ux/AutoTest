import { all, exec, get, insert, query, remove, update, now } from "./data/db.js";
import { executeCase, wrapScript } from "./execution-engine.js";
import { deliverExecutionAlerts } from "./alert-delivery.js";
import { randomBytes } from "node:crypto";
function casePreconditionIds(item) {
    const value = item.precondition_case_ids;
    let ids = [];
    if (Array.isArray(value))
        ids = value;
    else if (typeof value === "string" && value) {
        try {
            ids = JSON.parse(value);
        }
        catch {
            ids = [];
        }
    }
    const normalized = ids.map(String).filter(Boolean);
    if (normalized.length === 0 && item.precondition_case_id)
        normalized.push(String(item.precondition_case_id));
    return normalized;
}
function resolveCaseChain(item) {
    const chain = [];
    const visiting = new Set();
    const completed = new Set();
    const visit = (current) => {
        if (visiting.has(current.id))
            throw new CaseExecutionError("前置用例存在循环引用", 400);
        if (completed.has(current.id))
            return;
        visiting.add(current.id);
        for (const preconditionCaseId of casePreconditionIds(current)) {
            const precondition = get("cases", preconditionCaseId);
            if (!precondition)
                throw new CaseExecutionError(`前置用例不存在: ${preconditionCaseId}`, 400);
            visit(precondition);
        }
        if (!current.script)
            throw new CaseExecutionError(`用例“${current.name}”无脚本内容`, 400);
        visiting.delete(current.id);
        completed.add(current.id);
        chain.push(current);
    };
    visit(item);
    return chain;
}
function buildExecutionScript(chain) {
    const lines = [
        "import { test, expect } from '@playwright/test';",
        "",
        `test(${JSON.stringify(chain[chain.length - 1].name)}, async ({ page }) => {`,
    ];
    chain.forEach((caseItem, index) => {
        const stage = index < chain.length - 1 ? `前置用例 ${index + 1}/${chain.length - 1}` : "当前用例";
        lines.push(`  console.log(${JSON.stringify(`[${stage}] 开始: ${caseItem.name}`)});`);
        lines.push(wrapScript(String(caseItem.script)));
        lines.push(`  console.log(${JSON.stringify(`[${stage}] 完成: ${caseItem.name}`)});`);
    });
    lines.push("});");
    return lines.join("\n");
}
function buildVisualBaselines(chain) {
    const baselines = {};
    for (const caseItem of chain) {
        const steps = Array.isArray(caseItem.steps_json) ? caseItem.steps_json : [];
        for (const step of steps) {
            if (step?.action !== "assert" || step?.assertionType !== "image")
                continue;
            if (!step.expectedImage)
                throw new CaseExecutionError(`图片断言“${step.description || step.id}”未上传基准截图`, 400);
            baselines[String(step.id)] = {
                image: String(step.expectedImage),
                similarityThreshold: Number(step.imageSimilarityThreshold) || 99,
            };
        }
    }
    return baselines;
}
const activeExecutions = new Map();
const pendingJobs = [];
let runningCount = 0;
/**
 * 服务重启兜底：进程退出后，内存队列丢失，残留的 pending/running 记录永远无法完成。
 * 启动时把所有卡住的执行（UI 用例 + 接口集合 + 接口用例）标记为失败，并清空本地执行令牌。
 */
export function markInterruptedExecutions() {
    const ts = now();
    exec("UPDATE executions SET status = 'failed', end_time = ?, error_message = '服务重启，执行已中断' WHERE status IN ('pending', 'running')", ts);
    // api_collection_runs 已通过迁移补 error_message 列
    exec("UPDATE api_collection_runs SET status = 'failed', ended_at = ?, error_message = '服务重启，执行已中断' WHERE status IN ('pending', 'running')", ts);
    // api_executions 已通过迁移补 ended_at 列
    exec("UPDATE api_executions SET status = 'failed', ended_at = ?, error_message = '服务重启，执行已中断' WHERE status IN ('pending', 'running')", ts);
    exec("UPDATE executions SET runner_token = '' WHERE runner_token IS NOT NULL AND runner_token != ''");
}
export class CaseExecutionError extends Error {
    status;
    constructor(message, status) {
        super(message);
        this.status = status;
    }
}
function readSetting(key, fallback) {
    const row = query("SELECT value FROM settings WHERE key = ?", key)[0];
    if (!row)
        return fallback;
    try {
        return JSON.parse(row.value);
    }
    catch {
        return fallback;
    }
}
function getExecutionSettings() {
    return {
        maxConcurrency: Math.max(1, readSetting("maxConcurrency", 5)),
        defaultTimeout: Math.max(1000, readSetting("defaultTimeout", 60000)),
        retryOnFailure: readSetting("retryOnFailure", true),
        maxRetries: Math.max(0, readSetting("maxRetries", 2)),
        screenshotOnFailure: readSetting("screenshotOnFailure", true),
    };
}
function prepareCaseExecution(caseId, environmentId) {
    const item = get("cases", caseId);
    if (!item)
        throw new CaseExecutionError("用例不存在", 404);
    const caseChain = resolveCaseChain(item);
    const executionScript = buildExecutionScript(caseChain);
    const visualBaselines = buildVisualBaselines(caseChain);
    let baseUrl = "";
    const selectedEnvironmentId = environmentId || item.environment_id;
    if (selectedEnvironmentId) {
        const environment = get("environments", selectedEnvironmentId);
        if (environment && (environment.scope || "platform") !== "platform") {
            throw new CaseExecutionError("所选环境不是平台用例环境", 400);
        }
        if (environment)
            baseUrl = environment.url || "";
    }
    if (!baseUrl) {
        const gotoMatch = String(item.script).match(/page\.goto\s*\(\s*['"`]([^'"`]+)['"`]/);
        if (gotoMatch) {
            try {
                baseUrl = new URL(gotoMatch[1]).origin;
            }
            catch { /* relative URL */ }
        }
    }
    if (!baseUrl)
        baseUrl = "about:blank";
    return { item, executionScript, visualBaselines, baseUrl };
}
export function queueCaseExecution(caseId, environmentId) {
    const { item, executionScript, visualBaselines, baseUrl } = prepareCaseExecution(caseId, environmentId);
    const execId = `exec-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const willStart = runningCount < getExecutionSettings().maxConcurrency;
    insert("executions", {
        id: execId,
        case_id: item.id,
        case_name: item.name,
        status: willStart ? "running" : "pending",
        start_time: willStart ? now() : null,
        logs: "[]",
        steps: "[]",
        screenshots: "[]",
    });
    pendingJobs.push({ execId, item, executionScript, visualBaselines, baseUrl, controller: new AbortController() });
    drainQueue();
    return { id: execId, status: willStart ? "running" : "pending" };
}
export function createLocalCaseExecution(caseId, reportBaseUrl, environmentId) {
    const { item, executionScript, visualBaselines, baseUrl } = prepareCaseExecution(caseId, environmentId);
    const settings = getExecutionSettings();
    const executionId = `exec-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`;
    const token = randomBytes(24).toString("hex");
    insert("executions", {
        id: executionId,
        case_id: item.id,
        case_name: item.name,
        status: "running",
        start_time: now(),
        logs: JSON.stringify([{
                timestamp: new Date().toLocaleTimeString("zh-CN", { hour12: false }),
                level: "info",
                message: "等待访问者电脑上的本地执行器",
            }]),
        steps: "[]",
        screenshots: "[]",
        runner_token: token,
    });
    return {
        executionId,
        token,
        caseId: item.id,
        caseName: item.name,
        script: executionScript,
        baseUrl,
        reportUrl: `${reportBaseUrl.replace(/\/$/, "")}/api/executions/${executionId}/local-result`,
        options: {
            timeoutMs: settings.defaultTimeout,
            screenshotOnFailure: settings.screenshotOnFailure,
            retryOnFailure: settings.retryOnFailure,
            maxRetries: settings.maxRetries,
            visualBaselines,
        },
    };
}
export function completeLocalCaseExecution(executionId, token, result, runnerName = "本地执行器") {
    const execution = get("executions", executionId);
    if (!execution)
        throw new CaseExecutionError("执行记录不存在", 404);
    if (!token || token !== execution.runner_token)
        throw new CaseExecutionError("本地执行报告令牌无效", 403);
    if (!result || !["pass", "fail"].includes(result.status))
        throw new CaseExecutionError("本地执行结果格式无效", 400);
    const item = get("cases", execution.case_id) || { id: execution.case_id, name: execution.case_name };
    const status = result.status === "pass" ? "success" : "failed";
    const endTime = now();
    const logs = [
        { timestamp: new Date().toLocaleTimeString("zh-CN", { hour12: false }), level: "info", message: `执行节点: ${runnerName}` },
        ...(Array.isArray(result.logs) ? result.logs : []).map((log) => ({
            timestamp: new Date(log.timestamp).toLocaleTimeString("zh-CN", { hour12: false }),
            level: log.level,
            message: log.message,
        })),
    ];
    update("executions", executionId, {
        status,
        duration: Number(result.duration) || 0,
        end_time: endTime,
        logs: JSON.stringify(logs),
        steps: JSON.stringify(Array.isArray(result.steps) ? result.steps : []),
        error_message: result.error || null,
        screenshots: JSON.stringify(result.screenshot ? [result.screenshot] : []),
        runner_token: "",
    });
    persistReport(executionId, item, status, endTime);
    void deliverExecutionAlerts(item.name, status, result.error);
    return { id: executionId, status };
}
export function refreshExecutionQueue() {
    drainQueue();
}
function drainQueue() {
    const settings = getExecutionSettings();
    while (pendingJobs.length > 0 && runningCount < settings.maxConcurrency) {
        const job = pendingJobs.shift();
        if (job.controller.signal.aborted)
            continue;
        runningCount++;
        activeExecutions.set(job.execId, job.controller);
        update("executions", job.execId, { status: "running", start_time: now() });
        void runExecution(job, settings).finally(() => {
            runningCount--;
            activeExecutions.delete(job.execId);
            drainQueue();
        });
    }
}
async function runExecution(job, settings) {
    const { execId, item, executionScript, visualBaselines, baseUrl, controller } = job;
    try {
        let result = await executeCase(executionScript, item.name, baseUrl, controller.signal, {
            timeoutMs: settings.defaultTimeout,
            screenshotOnFailure: settings.screenshotOnFailure,
            visualBaselines,
        });
        const retryLimit = settings.retryOnFailure ? settings.maxRetries : 0;
        for (let attempt = 1; result.status === "fail" && !controller.signal.aborted && attempt <= retryLimit; attempt++) {
            result = await executeCase(executionScript, `${item.name}（重试 ${attempt}/${retryLimit}）`, baseUrl, controller.signal, {
                timeoutMs: settings.defaultTimeout,
                screenshotOnFailure: settings.screenshotOnFailure,
                visualBaselines,
            });
            result.logs.unshift({ timestamp: new Date().toISOString(), level: "warn", message: `失败后第 ${attempt} 次重试` });
        }
        const logs = result.logs.map((log) => ({
            timestamp: new Date(log.timestamp).toLocaleTimeString("zh-CN", { hour12: false }),
            level: log.level,
            message: log.message,
        }));
        const screenshots = result.screenshot ? [result.screenshot] : [];
        const status = controller.signal.aborted ? "cancelled" : result.status === "pass" ? "success" : "failed";
        const endTime = now();
        update("executions", execId, {
            status,
            duration: result.duration,
            end_time: endTime,
            logs: JSON.stringify(logs),
            steps: JSON.stringify(result.steps),
            error_message: result.error || null,
            screenshots: JSON.stringify(screenshots),
        });
        persistReport(execId, item, status, endTime);
        void deliverExecutionAlerts(item.name, status, result.error);
    }
    catch (error) {
        const message = error instanceof Error ? error.message : String(error);
        const cancelled = controller.signal.aborted;
        const status = cancelled ? "cancelled" : "failed";
        const endTime = now();
        update("executions", execId, {
            status,
            end_time: endTime,
            error_message: message,
            logs: JSON.stringify([{
                    timestamp: new Date().toLocaleTimeString("zh-CN", { hour12: false }),
                    level: cancelled ? "warn" : "error",
                    message: cancelled ? `执行已取消: ${message}` : `执行异常: ${message}`,
                }]),
        });
        persistReport(execId, item, status, endTime);
        void deliverExecutionAlerts(item.name, status, message);
    }
}
function persistReport(execId, item, status, endTime) {
    const execution = get("executions", execId);
    if (!execution)
        return;
    remove("reports", execId);
    insert("reports", {
        id: execId,
        execution_id: execId,
        case_id: item.id,
        case_name: item.name,
        status,
        start_time: execution.start_time,
        end_time: endTime,
        duration: execution.duration || null,
        error_message: execution.error_message || null,
        steps: JSON.stringify(execution.steps || []),
        screenshots: JSON.stringify(execution.screenshots || []),
        logs: JSON.stringify(execution.logs || []),
        created_at: endTime,
    });
}
export function cancelCaseExecutions(caseId) {
    const cancellable = all("executions").filter((execution) => execution.case_id === caseId && ["running", "pending"].includes(execution.status));
    let cancelled = 0;
    for (const execution of cancellable) {
        const active = activeExecutions.get(execution.id);
        if (active) {
            active.abort();
            cancelled++;
            continue;
        }
        const index = pendingJobs.findIndex((job) => job.execId === execution.id);
        if (index >= 0) {
            const [job] = pendingJobs.splice(index, 1);
            job.controller.abort();
            const endTime = now();
            update("executions", execution.id, { status: "cancelled", end_time: endTime, error_message: "排队执行已取消" });
            persistReport(execution.id, job.item, "cancelled", endTime);
            cancelled++;
        }
    }
    return { found: cancellable.length, cancelled };
}
//# sourceMappingURL=case-execution.js.map