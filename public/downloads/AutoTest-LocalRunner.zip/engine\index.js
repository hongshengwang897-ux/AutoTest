import express from "express";
import cors from "cors";
// 初始化 SQLite 数据库（导入即触发建表 + 播种）
import "./data/db.js";
import { closeDb } from "./data/db.js";
import { openPage, scanPageElements, receiveReport, closePage, getSession, getSessionElements, } from "./browser.js";
// Route modules
import casesRouter from "./routes/cases.js";
import executionsRouter from "./routes/executions.js";
import reportsRouter from "./routes/reports.js";
import elementsRouter from "./routes/elements.js";
import environmentsRouter from "./routes/environments.js";
import schedulesRouter from "./routes/schedules.js";
import alertsRouter from "./routes/alerts.js";
import statsRouter from "./routes/stats.js";
import settingsRouter from "./routes/settings.js";
import recorderRouter from "./routes/recorder.js";
import modulesRouter from "./routes/modules.js";
import apiTestsRouter from "./routes/api-tests.js";
import performanceTestsRouter from "./routes/performance-tests.js";
import securityRouter from "./routes/security.js";
import authRouter, { ensureApiToken, requireAuth } from "./auth.js";
import { markInterruptedExecutions } from "./case-execution.js";
import { initializeScheduler, shutdownScheduler } from "./scheduler.js";
const app = express();
const PORT = parseInt(process.env.PORT || "3001", 10);
app.use(cors());
app.use(express.json({ limit: "10mb" }));
// ---- 认证层 ----
// /api/auth/* 免认证（登录/状态探活）；其余 /api/* 需 Bearer Token（白名单见 auth.ts）
app.use("/api/auth", authRouter);
app.use("/api", requireAuth);
// ---- Core CRUD Routes ----
app.use("/api/cases", casesRouter);
app.use("/api/executions", executionsRouter);
app.use("/api/reports", reportsRouter);
app.use("/api/elements", elementsRouter);
app.use("/api/environments", environmentsRouter);
app.use("/api/schedules", schedulesRouter);
app.use("/api/alerts", alertsRouter);
app.use("/api/stats", statsRouter);
app.use("/api/settings", settingsRouter);
app.use("/api/recorder", recorderRouter);
app.use("/api/modules", modulesRouter);
app.use("/api/security", securityRouter);
app.use("/api/api-tests", apiTestsRouter);
app.use("/api/performance-tests", performanceTestsRouter);
app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", service: "auto-detect-api", timestamp: new Date().toISOString() });
});
app.all("/api/echo", (req, res) => {
    res.json({
        method: req.method,
        query: req.query,
        headers: req.headers,
        body: req.body ?? null,
    });
});
// ---- Auto-Detect Routes ----
/** POST /api/auto-detect/open — launch browser, navigate to URL, inject floating button */
app.post("/api/auto-detect/open", async (req, res) => {
    try {
        const { url, headless = false } = req.body;
        if (!url) {
            res.status(400).json({ error: "url is required" });
            return;
        }
        const protocol = req.protocol;
        const host = req.get("host") || `localhost:${PORT}`;
        const apiBaseUrl = `${protocol}://${host}`;
        const { sessionId } = await openPage(url, headless, apiBaseUrl);
        res.json({ sessionId, status: "ready" });
    }
    catch (err) {
        console.error("open error:", err.message);
        res.status(500).json({ error: err.message });
    }
});
/** POST /api/auto-detect/scan/:sessionId */
app.post("/api/auto-detect/scan/:sessionId", async (req, res) => {
    try {
        const { sessionId } = req.params;
        const result = await scanPageElements(sessionId);
        res.json(result);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
/** POST /api/auto-detect/report/:sessionId */
app.post("/api/auto-detect/report/:sessionId", (req, res) => {
    try {
        const { sessionId } = req.params;
        const { elements } = req.body;
        if (!Array.isArray(elements)) {
            res.status(400).json({ error: "elements array required" });
            return;
        }
        const result = receiveReport(sessionId, elements);
        res.json(result);
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
/** GET /api/auto-detect/status/:sessionId */
app.get("/api/auto-detect/status/:sessionId", (req, res) => {
    const session = getSession(req.params.sessionId);
    if (!session) {
        res.status(404).json({ error: "session not found" });
        return;
    }
    res.json({
        sessionId: session.sessionId,
        url: session.url,
        status: session.status,
        elementCount: session.elements.length,
    });
});
/** GET /api/auto-detect/elements/:sessionId */
app.get("/api/auto-detect/elements/:sessionId", (req, res) => {
    const elems = getSessionElements(req.params.sessionId);
    res.json({ elements: elems });
});
/** POST /api/auto-detect/close/:sessionId */
app.post("/api/auto-detect/close/:sessionId", async (req, res) => {
    try {
        await closePage(req.params.sessionId);
        res.json({ status: "closed" });
    }
    catch (err) {
        res.status(500).json({ error: err.message });
    }
});
app.listen(PORT, "0.0.0.0", () => {
    console.log(`[API] Server listening on 0.0.0.0:${PORT}`);
    console.log(`  Routes: /api/cases, /api/executions, /api/reports, /api/elements`);
    console.log(`  Routes: /api/environments, /api/schedules, /api/alerts, /api/stats`);
    console.log(`  Routes: /api/auto-detect/*, /api/settings, /api/modules, /api/api-tests, /api/performance-tests`);
    // 启动时确保 API Token 存在（优先 AUTOTEST_API_TOKEN，否则自动生成并持久化）
    ensureApiToken();
    // 启动兜底：重启前卡住的执行记录标记为失败（内存队列已丢失）
    markInterruptedExecutions();
    initializeScheduler();
});
// 优雅退出
process.on("SIGINT", () => { shutdownScheduler(); closeDb(); process.exit(0); });
process.on("SIGTERM", () => { shutdownScheduler(); closeDb(); process.exit(0); });
//# sourceMappingURL=index.js.map