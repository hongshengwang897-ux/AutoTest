import { all, query } from "./data/db.js";
export async function sendAlert(item, text) {
    const channel = String(item.channel || "");
    const target = String(item.webhook_url || item.webhookUrl || "").trim();
    if (channel === "email")
        throw new Error("邮件通道尚未配置 SMTP 服务");
    if (!/^https?:\/\//i.test(target))
        throw new Error("Webhook URL 无效");
    const body = channel === "dingtalk"
        ? { msgtype: "text", text: { content: text } }
        : channel === "feishu"
            ? { msg_type: "text", content: { text } }
            : { text, event: "execution" };
    const response = await fetch(target, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: AbortSignal.timeout(10000),
    });
    const responseText = await response.text();
    if (!response.ok)
        throw new Error(`Webhook 返回 HTTP ${response.status}: ${responseText.slice(0, 200)}`);
}
function readNotifications() {
    const row = query("SELECT value FROM settings WHERE key = ?", "notifications")[0];
    if (!row)
        return { executionComplete: true, failureOnly: false, systemAlerts: true };
    try {
        return JSON.parse(row.value);
    }
    catch {
        return { executionComplete: true, failureOnly: false, systemAlerts: true };
    }
}
export async function deliverExecutionAlerts(caseName, status, errorMessage) {
    const preferences = readNotifications();
    if (status === "success" && (!preferences.executionComplete || preferences.failureOnly))
        return;
    if (status !== "success" && preferences.systemAlerts === false)
        return;
    const level = status === "success" ? "success" : status === "timeout" ? "timeout" : "failed";
    const channels = all("alerts").filter((item) => {
        const levels = Array.isArray(item.notify_levels) ? item.notify_levels : [];
        return item.enabled && levels.includes(level);
    });
    await Promise.allSettled(channels.map(async (item) => {
        const template = String(item.template || "【自动化通知】用例「{{caseName}}」执行状态：{{status}} {{errorMessage}}");
        const replacements = {
            "{{caseName}}": caseName,
            "{{status}}": status,
            "{{errorMessage}}": errorMessage || "",
            "{{total}}": "1",
            "{{pass}}": status === "success" ? "1" : "0",
            "{{fail}}": status === "success" ? "0" : "1",
        };
        let message = template;
        for (const [token, value] of Object.entries(replacements))
            message = message.split(token).join(value);
        try {
            await sendAlert(item, message);
        }
        catch (error) {
            console.error(`[Alert] ${item.name}:`, error instanceof Error ? error.message : error);
        }
    }));
}
//# sourceMappingURL=alert-delivery.js.map