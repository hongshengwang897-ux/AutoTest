@echo off
chcp 65001 >nul
cd /d "%~dp0"
title AutoTest Local Runner Installer

where node >nul 2>nul
if errorlevel 1 (
  echo Node.js is required. Trying to install Node.js LTS with winget...
  where winget >nul 2>nul
  if errorlevel 1 (
    echo Node.js and winget were not found.
    echo Install Node.js LTS from https://nodejs.org and run this file again.
    pause
    exit /b 1
  )
  winget install OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
  if errorlevel 1 (
    echo Node.js installation failed.
    pause
    exit /b 1
  )
  set "PATH=%PATH%;C:\Program Files\nodejs"
)

echo Installing local runner dependencies...
set PLAYWRIGHT_SKIP_BROWSER_DOWNLOAD=1
call npm install --omit=dev
if errorlevel 1 (
  echo Dependency installation failed. Check the network and try again.
  pause
  exit /b 1
)

call "%~dp0start-runner.bat"
