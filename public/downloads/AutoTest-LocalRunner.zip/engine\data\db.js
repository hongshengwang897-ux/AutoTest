/**
 * SQLite 数据库层 — 替代内存存储
 * 使用 Node.js 22 内置的 node:sqlite
 */
import { DatabaseSync } from "node:sqlite";
import { join, dirname } from "node:path";
import { mkdirSync } from "node:fs";
import { fileURLToPath } from "node:url";
const __dirname = dirname(fileURLToPath(import.meta.url));
const DATA_DIR = join(__dirname, "..", "..", "data");
const DB_PATH = join(DATA_DIR, "app.db");
mkdirSync(DATA_DIR, { recursive: true });
const db = new DatabaseSync(DB_PATH);
// 性能优化
db.exec("PRAGMA journal_mode=WAL");
db.exec("PRAGMA synchronous=NORMAL");
db.exec("PRAGMA foreign_keys=ON");
// ---- 建表 ----
db.exec(`
  CREATE TABLE IF NOT EXISTS cases (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    script TEXT DEFAULT '',
    steps_json TEXT DEFAULT '[]',
    language TEXT DEFAULT 'typescript',
    tags TEXT DEFAULT '[]',
    group_name TEXT DEFAULT '',
    environment_id TEXT DEFAULT '',
    precondition_case_id TEXT DEFAULT '',
    precondition_case_ids TEXT DEFAULT '[]',
    status TEXT DEFAULT 'draft',
    version INTEGER DEFAULT 1,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )
`);
// 兼容已存在的数据库：新增字段时只做幂等迁移，不改动原有用例数据。
const caseColumns = db.prepare("PRAGMA table_info(cases)").all();
if (!caseColumns.some((column) => column.name === "steps_json")) {
    db.exec("ALTER TABLE cases ADD COLUMN steps_json TEXT DEFAULT '[]'");
}
if (!caseColumns.some((column) => column.name === "precondition_case_id")) {
    db.exec("ALTER TABLE cases ADD COLUMN precondition_case_id TEXT DEFAULT ''");
}
if (!caseColumns.some((column) => column.name === "precondition_case_ids")) {
    db.exec("ALTER TABLE cases ADD COLUMN precondition_case_ids TEXT DEFAULT '[]'");
}
// 将旧版单前置用例迁移为有序列表；保留旧字段供旧版执行器兼容读取。
const legacyPreconditions = db.prepare("SELECT id, precondition_case_id, precondition_case_ids FROM cases WHERE precondition_case_id <> ''").all();
const migratePrecondition = db.prepare("UPDATE cases SET precondition_case_ids = ? WHERE id = ?");
for (const item of legacyPreconditions) {
    const existing = parseJson(item.precondition_case_ids, []);
    if (existing.length === 0)
        migratePrecondition.run(JSON.stringify([item.precondition_case_id]), item.id);
}
db.exec(`
  CREATE TABLE IF NOT EXISTS elements (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT DEFAULT '',
    selector TEXT DEFAULT '',
    selector_type TEXT DEFAULT 'css',
    page TEXT DEFAULT '',
    description TEXT DEFAULT '',
    tags TEXT DEFAULT '[]',
    source TEXT DEFAULT 'manual',
    usage_count INTEGER DEFAULT 0,
    last_used TEXT,
    created_at TEXT NOT NULL
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS environments (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    url TEXT DEFAULT '',
    type TEXT DEFAULT 'dev',
    scope TEXT DEFAULT 'platform',
    variables TEXT DEFAULT '{}',
    accounts TEXT DEFAULT '[]',
    status TEXT DEFAULT 'online'
  )
`);
const environmentColumns = db.prepare("PRAGMA table_info(environments)").all();
if (!environmentColumns.some((column) => column.name === "scope")) {
    db.exec("ALTER TABLE environments ADD COLUMN scope TEXT DEFAULT 'platform'");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS executions (
    id TEXT PRIMARY KEY,
    case_id TEXT DEFAULT '',
    case_name TEXT DEFAULT '',
    status TEXT DEFAULT 'pending',
    start_time TEXT,
    end_time TEXT,
    duration INTEGER,
    error_message TEXT,
    logs TEXT DEFAULT '[]',
    steps TEXT DEFAULT '[]',
    screenshots TEXT DEFAULT '[]',
    runner_token TEXT DEFAULT ''
  )
`);
const executionColumns = db.prepare("PRAGMA table_info(executions)").all();
if (!executionColumns.some((column) => column.name === "runner_token")) {
    db.exec("ALTER TABLE executions ADD COLUMN runner_token TEXT DEFAULT ''");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS reports (
    id TEXT PRIMARY KEY,
    execution_id TEXT DEFAULT '',
    case_id TEXT DEFAULT '',
    case_name TEXT DEFAULT '',
    status TEXT DEFAULT 'success',
    start_time TEXT,
    end_time TEXT,
    duration INTEGER,
    error_message TEXT,
    steps TEXT DEFAULT '[]',
    screenshots TEXT DEFAULT '[]',
    logs TEXT DEFAULT '[]',
    created_at TEXT NOT NULL
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS schedules (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    cron_expression TEXT DEFAULT '',
    case_ids TEXT DEFAULT '[]',
    environment_id TEXT DEFAULT '',
    enabled INTEGER DEFAULT 0,
    last_run_time TEXT,
    next_run_time TEXT
  )
`);
const scheduleColumns = db.prepare("PRAGMA table_info(schedules)").all();
if (!scheduleColumns.some((column) => column.name === "target_type")) {
    db.exec("ALTER TABLE schedules ADD COLUMN target_type TEXT DEFAULT 'platform'");
}
if (!scheduleColumns.some((column) => column.name === "collection_path")) {
    db.exec("ALTER TABLE schedules ADD COLUMN collection_path TEXT DEFAULT ''");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS alerts (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    channel TEXT DEFAULT 'dingtalk',
    webhook_url TEXT DEFAULT '',
    notify_levels TEXT DEFAULT '[]',
    template TEXT DEFAULT '',
    enabled INTEGER DEFAULT 0
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  )
`);
db.exec(`
  CREATE TABLE IF NOT EXISTS api_cases (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    method TEXT DEFAULT 'GET',
    url TEXT DEFAULT '',
    headers TEXT DEFAULT '[]',
    query_params TEXT DEFAULT '[]',
    body_type TEXT DEFAULT 'none',
    body TEXT DEFAULT '',
    assertions TEXT DEFAULT '[]',
    variables TEXT DEFAULT '{}',
    environment_id TEXT DEFAULT '',
    group_name TEXT DEFAULT '',
    sort_order INTEGER DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )
`);
const apiCaseColumns = db.prepare("PRAGMA table_info(api_cases)").all();
if (!apiCaseColumns.some((column) => column.name === "sort_order")) {
    db.exec("ALTER TABLE api_cases ADD COLUMN sort_order INTEGER DEFAULT 0");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS api_executions (
    id TEXT PRIMARY KEY,
    case_id TEXT DEFAULT '',
    case_name TEXT DEFAULT '',
    status TEXT DEFAULT 'success',
    method TEXT DEFAULT 'GET',
    url TEXT DEFAULT '',
    status_code INTEGER,
    duration INTEGER DEFAULT 0,
    response_size INTEGER DEFAULT 0,
    request_headers TEXT DEFAULT '{}',
    request_body TEXT DEFAULT '',
    response_headers TEXT DEFAULT '{}',
    response_body TEXT DEFAULT '',
    assertion_results TEXT DEFAULT '[]',
    error_message TEXT,
    created_at TEXT NOT NULL
  )
`);
// 兼容旧库：api_executions 补 ended_at 列（幂等）
const apiExecutionColumns = db.prepare("PRAGMA table_info(api_executions)").all();
if (!apiExecutionColumns.some((column) => column.name === "ended_at")) {
    db.exec("ALTER TABLE api_executions ADD COLUMN ended_at TEXT");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS api_collection_runs (
    id TEXT PRIMARY KEY,
    collection_path TEXT NOT NULL,
    collection_name TEXT NOT NULL,
    schedule_id TEXT DEFAULT '',
    trigger_type TEXT DEFAULT 'manual',
    environment_id TEXT DEFAULT '',
    status TEXT DEFAULT 'running',
    total INTEGER DEFAULT 0,
    passed INTEGER DEFAULT 0,
    failed INTEGER DEFAULT 0,
    duration INTEGER DEFAULT 0,
    items TEXT DEFAULT '[]',
    started_at TEXT NOT NULL,
    ended_at TEXT,
    created_at TEXT NOT NULL
  )
`);
// 兼容旧库：api_collection_runs 补 error_message 列（幂等）
const apiCollectionRunColumns = db.prepare("PRAGMA table_info(api_collection_runs)").all();
if (!apiCollectionRunColumns.some((column) => column.name === "error_message")) {
    db.exec("ALTER TABLE api_collection_runs ADD COLUMN error_message TEXT");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS performance_scenarios (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT DEFAULT '',
    target_type TEXT DEFAULT 'cases',
    target_ids TEXT DEFAULT '[]',
    custom_requests TEXT DEFAULT '[]',
    collection_path TEXT DEFAULT '',
    environment_id TEXT DEFAULT '',
    concurrency INTEGER DEFAULT 10,
    execution_mode TEXT DEFAULT 'samples',
    sample_count INTEGER DEFAULT 1000,
    duration_seconds INTEGER DEFAULT 60,
    ramp_up_seconds INTEGER DEFAULT 0,
    timeout_ms INTEGER DEFAULT 30000,
    think_time_ms INTEGER DEFAULT 0,
    use_proxy_pool INTEGER DEFAULT 0,
    success_rate_threshold REAL DEFAULT 95,
    p95_threshold_ms INTEGER DEFAULT 2000,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )
`);
const performanceScenarioColumns = db.prepare("PRAGMA table_info(performance_scenarios)").all();
if (!performanceScenarioColumns.some((column) => column.name === "custom_requests")) {
    db.exec("ALTER TABLE performance_scenarios ADD COLUMN custom_requests TEXT DEFAULT '[]'");
}
if (!performanceScenarioColumns.some((column) => column.name === "execution_mode")) {
    db.exec("ALTER TABLE performance_scenarios ADD COLUMN execution_mode TEXT DEFAULT 'duration'");
}
if (!performanceScenarioColumns.some((column) => column.name === "sample_count")) {
    db.exec("ALTER TABLE performance_scenarios ADD COLUMN sample_count INTEGER DEFAULT 1000");
}
if (!performanceScenarioColumns.some((column) => column.name === "use_proxy_pool")) {
    db.exec("ALTER TABLE performance_scenarios ADD COLUMN use_proxy_pool INTEGER DEFAULT 0");
}
db.exec(`
  CREATE TABLE IF NOT EXISTS performance_runs (
    id TEXT PRIMARY KEY,
    scenario_id TEXT NOT NULL,
    scenario_name TEXT NOT NULL,
    status TEXT DEFAULT 'pending',
    started_at TEXT,
    ended_at TEXT,
    duration INTEGER DEFAULT 0,
    total_requests INTEGER DEFAULT 0,
    successful_requests INTEGER DEFAULT 0,
    failed_requests INTEGER DEFAULT 0,
    bytes_received INTEGER DEFAULT 0,
    bytes_sent INTEGER DEFAULT 0,
    avg_response_time REAL DEFAULT 0,
    min_response_time REAL DEFAULT 0,
    max_response_time REAL DEFAULT 0,
    p50_response_time REAL DEFAULT 0,
    p90_response_time REAL DEFAULT 0,
    p95_response_time REAL DEFAULT 0,
    p99_response_time REAL DEFAULT 0,
    requests_per_second REAL DEFAULT 0,
    error_rate REAL DEFAULT 0,
    metrics TEXT DEFAULT '[]',
    errors TEXT DEFAULT '[]',
    status_codes TEXT DEFAULT '{}',
    transactions TEXT DEFAULT '[]',
    sla_results TEXT DEFAULT '[]',
    config TEXT DEFAULT '{}',
    error_message TEXT DEFAULT '',
    created_at TEXT NOT NULL
  )
`);
const performanceRunColumns = db.prepare("PRAGMA table_info(performance_runs)").all();
if (!performanceRunColumns.some((column) => column.name === "bytes_sent")) {
    db.exec("ALTER TABLE performance_runs ADD COLUMN bytes_sent INTEGER DEFAULT 0");
}
if (!performanceRunColumns.some((column) => column.name === "transactions")) {
    db.exec("ALTER TABLE performance_runs ADD COLUMN transactions TEXT DEFAULT '[]'");
}
if (!performanceRunColumns.some((column) => column.name === "sla_results")) {
    db.exec("ALTER TABLE performance_runs ADD COLUMN sla_results TEXT DEFAULT '[]'");
}
// ★ 模块目录表 — 支持嵌套
db.exec(`
  CREATE TABLE IF NOT EXISTS modules (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    parent_id TEXT DEFAULT '',
    sort_order INTEGER DEFAULT 0,
    created_at TEXT DEFAULT ''
  )
`);
// ---- 种子数据 ----
function parseJson(raw, fallback) {
    if (!raw)
        return fallback;
    try {
        return JSON.parse(raw);
    }
    catch {
        return fallback;
    }
}
function toJson(obj) {
    return JSON.stringify(obj);
}
// 只在表为空时播种
const countResult = db.prepare("SELECT COUNT(*) as c FROM cases").get();
const modCount = db.prepare("SELECT COUNT(*) as c FROM modules").get().c;
// 种子数据：cases 为空 → 全量播种；modules 为空 → 补充播种
if (countResult.c === 0 || modCount === 0) {
    if (countResult.c === 0) {
        const now = new Date().toISOString();
        const seedCases = [
            {
                id: "case-1", name: "登录功能回归", description: "验证登录页面的正常登录、错误提示、密码找回功能",
                script: `import { test, expect } from '@playwright/test';\ntest('正常登录', async ({ page }) => {\n  await page.goto('/login');\n  await page.fill('[name="username"]', 'admin');\n  await page.fill('[name="password"]', 'pass123');\n  await page.click('button[type="submit"]');\n  await expect(page).toHaveURL('/dashboard');\n});`,
                language: "typescript", tags: ["登录", "P0", "回归"], group_name: "用户模块", environment_id: "env-1", status: "active", version: 3,
                created_at: "2026-07-20T08:00:00Z", updated_at: "2026-07-23T10:30:00Z",
            },
            {
                id: "case-2", name: "订单创建流程", description: "端到端测试：搜索商品 → 加购物车 → 结算 → 确认订单",
                script: `import { test, expect } from '@playwright/test';\ntest('创建订单', async ({ page }) => {\n  await page.goto('/products');\n  await page.click('[data-testid="add-cart-1"]');\n  await page.click('[data-testid="checkout"]');\n  await page.fill('[name="address"]', '北京市朝阳区');\n  await page.click('[data-testid="confirm-order"]');\n  await expect(page.locator('.success')).toBeVisible();\n});`,
                language: "typescript", tags: ["订单", "P0", "端到端"], group_name: "交易模块", environment_id: "env-2", status: "active", version: 5,
                created_at: "2026-07-18T09:00:00Z", updated_at: "2026-07-23T14:00:00Z",
            },
            {
                id: "case-3", name: "搜索功能验证", description: "验证商品搜索的精确匹配、模糊匹配和空结果处理",
                script: "", language: "typescript", tags: ["搜索", "P1"], group_name: "商品模块", environment_id: "env-1", status: "draft", version: 1,
                created_at: "2026-07-22T11:00:00Z", updated_at: "2026-07-22T11:00:00Z",
            },
        ];
        const seedExecs = [
            {
                id: "exec-1", case_id: "case-1", case_name: "登录功能回归", status: "success",
                start_time: "2026-07-24T09:00:00Z", end_time: "2026-07-24T09:02:15Z", duration: 135000, error_message: null,
                logs: toJson([{ timestamp: "09:00:01", level: "info", message: "开始执行：登录功能回归" }, { timestamp: "09:02:15", level: "info", message: "执行完成：通过" }]),
                steps: toJson([]), screenshots: toJson([]),
            },
            {
                id: "exec-2", case_id: "case-2", case_name: "订单创建流程", status: "running",
                start_time: "2026-07-24T09:10:00Z", end_time: null, duration: null, error_message: null,
                logs: toJson([{ timestamp: "09:10:01", level: "info", message: "开始执行：订单创建流程" }]),
                steps: toJson([]), screenshots: toJson([]),
            },
            {
                id: "exec-3", case_id: "case-1", case_name: "登录功能回归", status: "failed",
                start_time: "2026-07-23T14:00:00Z", end_time: "2026-07-23T14:01:42Z", duration: 102000,
                error_message: "元素未找到: button[type='submit']，可能页面结构已变更",
                logs: toJson([{ timestamp: "14:01:40", level: "error", message: "✗ 元素未找到: button[type='submit']" }]),
                steps: toJson([]), screenshots: toJson([]),
            },
        ];
        const seedElements = [
            { id: "el-1", name: "登录按钮", type: "button", selector: "button[type='submit']", selector_type: "css", page: "登录页", description: "登录表单的提交按钮", tags: ["登录", "P0"], source: "recording", usage_count: 12, last_used: "2026-07-24T09:00:00Z", created_at: "2026-07-15T08:00:00Z" },
            { id: "el-2", name: "用户名输入框", type: "input", selector: 'input[name="username"]', selector_type: "css", page: "登录页", description: "用户名输入框", tags: ["登录"], source: "recording", usage_count: 18, last_used: "2026-07-24T09:00:00Z", created_at: "2026-07-15T08:00:00Z" },
            { id: "el-3", name: "密码输入框", type: "input", selector: 'input[name="password"]', selector_type: "css", page: "登录页", description: "密码输入框", tags: ["登录"], source: "recording", usage_count: 18, last_used: "2026-07-24T09:00:00Z", created_at: "2026-07-15T08:00:00Z" },
            { id: "el-4", name: "搜索框", type: "input", selector: '[data-testid="search-input"]', selector_type: "css", page: "首页", description: "全局搜索输入框", tags: ["导航", "P1"], source: "auto-import", usage_count: 5, created_at: "2026-07-20T10:00:00Z" },
            { id: "el-5", name: "确认订单按钮", type: "button", selector: '[data-testid="confirm-order"]', selector_type: "css", page: "结算页", description: "确认订单并提交", tags: ["订单", "P0"], source: "manual", usage_count: 3, created_at: "2026-07-22T15:00:00Z" },
        ];
        const seedEnvs = [
            { id: "env-1", name: "开发环境", url: "https://dev.example.com", type: "dev", variables: { API_URL: "https://api-dev.example.com" }, accounts: [{ username: "qa01", password: "qa01pass", role: "测试账号" }], status: "online" },
            { id: "env-2", name: "预发布环境", url: "https://staging.example.com", type: "staging", variables: { API_URL: "https://api-staging.example.com" }, accounts: [{ username: "stage01", password: "stagepass", role: "预发布测试" }], status: "online" },
            { id: "env-3", name: "生产环境", url: "https://www.example.com", type: "prod", variables: { API_URL: "https://api.example.com" }, accounts: [], status: "online" },
        ];
        const seedSchedules = [
            { id: "sched-1", name: "每日回归测试", cron_expression: "0 8 * * 1-5", case_ids: ["case-1", "case-2"], environment_id: "env-2", enabled: 1, last_run_time: "2026-07-24T08:00:00Z", next_run_time: "2026-07-25T08:00:00Z" },
            { id: "sched-2", name: "登录冒烟测试", cron_expression: "*/30 * * * *", case_ids: ["case-1"], environment_id: "env-1", enabled: 0 },
        ];
        const seedAlerts = [
            { id: "alert-1", name: "失败通知-钉钉", channel: "dingtalk", webhook_url: "https://oapi.dingtalk.com/robot/send?access_token=xxx", notify_levels: ["failed", "timeout"], template: "【自动化告警】用例「{{caseName}}」执行失败：{{errorMessage}}", enabled: 1 },
            { id: "alert-2", name: "日报-飞书", channel: "feishu", webhook_url: "https://open.feishu.cn/open-apis/bot/v2/hook/xxx", notify_levels: ["success", "failed"], template: "【日报】今日执行 {{total}} 条，通过 {{pass}} 条，失败 {{fail}} 条", enabled: 1 },
        ];
        const insertCase = db.prepare("INSERT INTO cases (id, name, description, script, language, tags, group_name, environment_id, status, version, created_at, updated_at) VALUES (@id, @name, @description, @script, @language, @tags, @group_name, @environment_id, @status, @version, @created_at, @updated_at)");
        for (const c of seedCases)
            insertCase.run({ ...c, tags: toJson(c.tags) });
        const insertExec = db.prepare("INSERT INTO executions (id, case_id, case_name, status, start_time, end_time, duration, error_message, logs, steps, screenshots) VALUES (@id, @case_id, @case_name, @status, @start_time, @end_time, @duration, @error_message, @logs, @steps, @screenshots)");
        for (const e of seedExecs)
            insertExec.run(e);
        const insertEl = db.prepare("INSERT INTO elements VALUES (@id, @name, @type, @selector, @selector_type, @page, @description, @tags, @source, @usage_count, @last_used, @created_at)");
        for (const el of seedElements)
            insertEl.run({ ...el, tags: toJson(el.tags), last_used: el.last_used || null });
        const insertEnv = db.prepare("INSERT INTO environments (id, name, url, type, variables, accounts, status) VALUES (@id, @name, @url, @type, @variables, @accounts, @status)");
        for (const e of seedEnvs)
            insertEnv.run({ ...e, variables: toJson(e.variables), accounts: toJson(e.accounts) });
        const insertSched = db.prepare("INSERT INTO schedules (id, name, cron_expression, case_ids, environment_id, enabled, last_run_time, next_run_time) VALUES (@id, @name, @cron_expression, @case_ids, @environment_id, @enabled, @last_run_time, @next_run_time)");
        for (const s of seedSchedules)
            insertSched.run({ ...s, case_ids: toJson(s.case_ids), last_run_time: s.last_run_time || null, next_run_time: s.next_run_time || null });
        const insertAlert = db.prepare("INSERT INTO alerts VALUES (@id, @name, @channel, @webhook_url, @notify_levels, @template, @enabled)");
        for (const a of seedAlerts)
            insertAlert.run({ ...a, notify_levels: toJson(a.notify_levels) });
        console.log(`[DB] 种子数据已写入 ${DB_PATH}`);
    } // 关闭 countResult.c === 0 块
    // ★ 种子模块 — 独立播种（不依赖 cases 为空）
    if (modCount === 0) {
        const now = new Date().toISOString();
        const seedMods = [
            { id: createId(), name: "登录模块", parent_id: "", sort_order: 10, created_at: now },
            { id: createId(), name: "首页", parent_id: "", sort_order: 20, created_at: now },
            { id: createId(), name: "货物管理", parent_id: "", sort_order: 30, created_at: now },
            { id: createId(), name: "订单管理", parent_id: "", sort_order: 40, created_at: now },
        ];
        const insertMod = db.prepare("INSERT INTO modules VALUES (@id, @name, @parent_id, @sort_order, @created_at)");
        for (const m of seedMods)
            insertMod.run(m);
    }
}
// ---- 导出工具函数 ----
export function createId() {
    return `${Date.now()}-${Math.random().toString(36).slice(2, 10)}`;
}
export function now() {
    return new Date().toISOString();
}
/** 获取表的所有行，自动解析 JSON 字段 */
export function all(table) {
    const rows = db.prepare(`SELECT * FROM ${table}`).all();
    return rows.map((r) => expandRow(table, r));
}
/** 根据 ID 获取一行 */
export function get(table, id) {
    const row = db.prepare(`SELECT * FROM ${table} WHERE id = ?`).get(id);
    return row ? expandRow(table, row) : null;
}
/** 插入一行 */
export function insert(table, data) {
    const cols = Object.keys(data);
    const placeholders = cols.map(() => "?").join(", ");
    const values = cols.map((c) => data[c]);
    db.prepare(`INSERT INTO ${table} (${cols.join(", ")}) VALUES (${placeholders})`).run(...values);
}
/** 更新一行 */
export function update(table, id, data) {
    const cols = Object.keys(data);
    if (cols.length === 0)
        return false;
    const sets = cols.map((c) => `${c} = ?`).join(", ");
    const values = cols.map((c) => data[c]);
    values.push(id);
    const result = db.prepare(`UPDATE ${table} SET ${sets} WHERE id = ?`).run(...values);
    return result.changes > 0;
}
/** 删除一行 */
export function remove(table, id) {
    const result = db.prepare(`DELETE FROM ${table} WHERE id = ?`).run(id);
    return result.changes > 0;
}
/** 执行原始 SQL（用于复杂查询），自动展开 JSON 字段 */
export function query(sql, ...params) {
    const rows = db.prepare(sql).all(...params);
    // 尝试根据 FROM 子句推断表名来展开
    const tableMatch = sql.match(/FROM\s+(\w+)/i);
    const table = tableMatch ? tableMatch[1] : "";
    return rows.map((r) => (table ? expandRow(table, r) : r));
}
/** 执行写入 SQL */
export function exec(sql, ...params) {
    return db.prepare(sql).run(...params).changes;
}
// ---- JSON 字段展开 ----
const JSON_FIELDS = {
    cases: ["tags", "steps_json", "precondition_case_ids"],
    elements: ["tags"],
    environments: ["variables", "accounts"],
    executions: ["logs", "steps", "screenshots"],
    reports: ["steps", "screenshots", "logs"],
    schedules: ["case_ids"],
    alerts: ["notify_levels"],
    api_cases: ["headers", "query_params", "assertions", "variables"],
    api_executions: ["request_headers", "response_headers", "assertion_results"],
    api_collection_runs: ["items"],
    performance_scenarios: ["target_ids", "custom_requests"],
    performance_runs: ["metrics", "errors", "status_codes", "transactions", "sla_results", "config"],
};
const BOOLEAN_FIELDS = {
    schedules: ["enabled"],
    alerts: ["enabled"],
    performance_scenarios: ["use_proxy_pool"],
};
function expandRow(table, row) {
    const result = { ...row };
    const jsonFields = JSON_FIELDS[table] || [];
    for (const f of jsonFields) {
        result[f] = parseJson(result[f], f === "case_ids" || f === "precondition_case_ids" || f === "tags" || f === "notify_levels" || f === "screenshots" || f === "logs" || f === "steps" || f === "steps_json" || f === "headers" || f === "query_params" || f === "assertions" || f === "assertion_results"
            ? []
            : {});
    }
    // 布尔字段转换
    const booleans = BOOLEAN_FIELDS[table] || [];
    for (const f of booleans) {
        result[f] = !!result[f];
    }
    return result;
}
/** 压缩 JSON 字段用于写入 */
export function compactRow(table, data) {
    const result = { ...data };
    const jsonFields = JSON_FIELDS[table] || [];
    for (const f of jsonFields) {
        if (f in result)
            result[f] = toJson(result[f]);
    }
    const booleans = BOOLEAN_FIELDS[table] || [];
    for (const f of booleans) {
        if (f in result)
            result[f] = result[f] ? 1 : 0;
    }
    return result;
}
/** 关闭数据库（进程退出时调用） */
export function closeDb() {
    db.close();
}
//# sourceMappingURL=db.js.map