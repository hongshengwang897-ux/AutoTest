import { chromium } from "playwright";
import { v4 as uuid } from "uuid";
import { buildInjectionScript } from "./inject.js";
import { dedupBySelector } from "./dedup.js";
const sessions = new Map();
const browserInstances = {};
export async function getBrowser(headless) {
    const key = headless ? "headless" : "headful";
    const existing = browserInstances[key];
    if (existing && existing.isConnected())
        return existing;
    const launchOptions = {
        headless,
        args: ["--no-sandbox", "--disable-setuid-sandbox"],
    };
    let browser;
    if (process.env.AUTOTEST_LOCAL_RUNNER === "1") {
        const preferred = process.env.AUTOTEST_BROWSER_CHANNEL || "chrome";
        const channels = Array.from(new Set([preferred, "chrome", "msedge"]));
        let lastError;
        browser = null;
        for (const channel of channels) {
            try {
                browser = await chromium.launch({ ...launchOptions, channel });
                break;
            }
            catch (error) {
                lastError = error;
            }
        }
        if (!browser) {
            throw new Error(`无法启动本机 Chrome 或 Edge: ${lastError instanceof Error ? lastError.message : String(lastError)}`);
        }
    }
    else {
        browser = await chromium.launch(launchOptions);
    }
    browserInstances[key] = browser;
    return browser;
}
export async function openPage(url, headless, apiBaseUrl) {
    // 安全校验：仅允许 http/https，阻止 file://、data:、私有网络/云元数据等 SSRF 目标
    let parsedUrl;
    try {
        parsedUrl = new URL(url);
    }
    catch {
        throw new Error("URL 格式无效，请输入完整的网址");
    }
    if (!["http:", "https:"].includes(parsedUrl.protocol)) {
        throw new Error("仅支持 HTTP 或 HTTPS URL");
    }
    const host = parsedUrl.hostname.toLowerCase();
    const isPrivate = host === "localhost"
        || host.endsWith(".localhost")
        || /^(127\.|10\.|192\.168\.|172\.(1[6-9]|2[0-9]|3[0-1])\.)/.test(host)
        || host === "0.0.0.0"
        || host === "[::1]"
        || host === "::1"
        || /^169\.254\./.test(host);
    if (isPrivate) {
        throw new Error(`目标地址为私有/内网地址，出于安全考虑已拒绝: ${host}`);
    }
    const sessionId = uuid();
    const browser = await getBrowser(headless);
    const context = await browser.newContext({
        viewport: { width: 1440, height: 900 },
        // headless mode: if user wants headful, we set the channel differently
        // Playwright's headless is per-launch; we handle via launch options
    });
    const page = await context.newPage();
    // Store session
    const session = {
        sessionId,
        url,
        headless,
        status: "opening",
        elements: [],
        createdAt: new Date().toISOString(),
    };
    sessions.set(sessionId, session);
    // Navigate
    try {
        await page.goto(parsedUrl.toString(), { waitUntil: "domcontentloaded", timeout: 30000 });
    }
    catch (error) {
        // 失败时清理已注册的会话与页面，避免泄漏
        sessions.delete(sessionId);
        try {
            await page.close();
        }
        catch { /* page may already be closed */ }
        try {
            await context.close();
        }
        catch { /* context may already be closed */ }
        throw error;
    }
    // Inject floating button
    const reportUrl = `${apiBaseUrl}/api/auto-detect/report/${sessionId}`;
    const script = buildInjectionScript(reportUrl);
    await page.evaluate(script);
    session.status = "ready";
    // Store page reference for later cleanup
    session._page = page;
    session._context = context;
    return { sessionId };
}
export async function scanPageElements(sessionId) {
    const session = sessions.get(sessionId);
    if (!session)
        throw new Error("Session not found");
    const page = session._page;
    if (!page)
        throw new Error("Page not available");
    session.status = "scanning";
    // Execute scan in page context — use raw string to avoid tsx transforms
    const rawElements = await page.evaluate(`
    (() => {
      const selectors = [
        'button, [role="button"], input[type="submit"], input[type="button"]',
        'input:not([type="submit"]):not([type="button"]):not([type="hidden"]):not([type="checkbox"]):not([type="radio"]), textarea',
        'a[href]',
        'img',
        'select',
        'input[type="checkbox"]',
        'input[type="radio"]',
        'nav, header, footer, main, section, [role="navigation"], [role="banner"]',
      ];

      function isVisible(el) {
        var style = window.getComputedStyle(el);
        if (style.display === 'none' || style.visibility === 'hidden' || style.opacity === '0')
          return false;
        var rect = el.getBoundingClientRect();
        return !(rect.width === 0 && rect.height === 0);
      }

      function getType(el) {
        var tag = el.tagName.toLowerCase();
        var role = el.getAttribute('role');
        var typeAttr = (el.getAttribute('type') || '').toLowerCase();
        if (tag === 'button' || role === 'button' || typeAttr === 'submit' || typeAttr === 'button')
          return 'button';
        if (tag === 'a' || role === 'link') return 'link';
        if (tag === 'img') return 'image';
        if (tag === 'select' || role === 'listbox' || role === 'combobox') return 'select';
        if (typeAttr === 'checkbox' || role === 'checkbox') return 'checkbox';
        if (typeAttr === 'radio' || role === 'radio') return 'radio';
        if (tag === 'input' || tag === 'textarea') return 'input';
        if (tag === 'label' || tag === 'span' || tag === 'p' ||
            tag === 'h1' || tag === 'h2' || tag === 'h3' || tag === 'h4' || tag === 'h5' || tag === 'h6')
          return 'text';
        return 'container';
      }

      function buildSelector(el) {
        var tag = el.tagName.toLowerCase();
        var dataTestid = el.getAttribute('data-testid');
        var id = el.getAttribute('id');
        var name = el.getAttribute('name');
        if (dataTestid) return { s: '[data-testid="' + dataTestid.replace(/"/g, '\\\\"') + '"]', t: 'css' };
        if (id && /^[a-zA-Z_][\\w.:-]*$/.test(id)) return { s: '#' + id, t: 'css' };
        if (name && tag === 'input') return { s: 'input[name="' + name.replace(/"/g, '\\\\"') + '"]', t: 'css' };
        var parent = el.parentElement;
        if (parent) {
          var siblings = Array.from(parent.children).filter(function(c) { return c.tagName === el.tagName; });
          var idx = siblings.indexOf(el);
          if (idx >= 0) return { s: tag + ':nth-of-type(' + (idx + 1) + ')', t: 'css' };
        }
        return { s: tag, t: 'css' };
      }

      function suggestName(el, type) {
        var attrs = ['aria-label', 'data-testid', 'data-name', 'placeholder', 'title', 'alt', 'name', 'id'];
        for (var i = 0; i < attrs.length; i++) {
          var v = el.getAttribute(attrs[i]);
          if (v && v.length <= 30) return v;
        }
        var text = (el.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 30);
        if (text) return text;
        var map = { button: '按钮', input: '输入框', text: '文本', link: '链接', image: '图片', select: '下拉选择', checkbox: '复选框', radio: '单选框', container: '容器' };
        return (map[type] || '元素') + ' (' + el.tagName.toLowerCase() + ')';
      }

      function describeElement(el, type) {
        var text = (el.textContent || '').replace(/\\s+/g, ' ').trim().slice(0, 50);
        if (type === 'button') return text ? '按钮: "' + text + '"' : '按钮元素';
        if (type === 'input') return el.getAttribute('placeholder') ? '输入框: ' + el.getAttribute('placeholder') : '输入框';
        if (type === 'link') return text ? '链接: ' + text : '链接元素';
        if (type === 'image') return el.getAttribute('alt') ? '图片: ' + el.getAttribute('alt') : '图片元素';
        if (type === 'select') return '下拉选择框';
        return text || '页面元素';
      }

      var raw = [];
      for (var s = 0; s < selectors.length; s++) {
        try {
          var nodes = document.querySelectorAll(selectors[s]);
          for (var i = 0; i < nodes.length; i++) {
            var el = nodes[i];
            if (!isVisible(el)) continue;
            var type = getType(el);
            var sel = buildSelector(el);
            raw.push({
              id: 'det-' + raw.length,
              suggestedName: suggestName(el, type),
              type: type,
              selector: sel.s,
              selectorType: sel.t,
              description: describeElement(el, type),
              tag: null,
              checked: true,
            });
            if (raw.length >= 200) break;
          }
        } catch (_) {}
        if (raw.length >= 200) break;
      }
      return raw;
    })()
  `);
    const totalFound = rawElements.length;
    const elements = dedupBySelector(rawElements);
    session.elements = elements;
    session.status = "ready";
    return { elements, totalFound, afterDedup: elements.length };
}
export function receiveReport(sessionId, rawElements) {
    const session = sessions.get(sessionId);
    if (!session)
        throw new Error("Session not found");
    const totalFound = rawElements.length;
    const elements = dedupBySelector(rawElements);
    session.elements = elements;
    session.status = "ready";
    return { elements, totalFound, afterDedup: elements.length };
}
export async function closePage(sessionId) {
    const session = sessions.get(sessionId);
    if (!session)
        return;
    try {
        const context = session._context;
        if (context)
            await context.close();
    }
    catch (_) {
        // Ignore cleanup errors
    }
    session.status = "closed";
    sessions.delete(sessionId);
}
export function getSession(sessionId) {
    return sessions.get(sessionId);
}
export function getSessionElements(sessionId) {
    const session = sessions.get(sessionId);
    return session?.elements || [];
}
//# sourceMappingURL=browser.js.map