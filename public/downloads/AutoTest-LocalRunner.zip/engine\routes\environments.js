import { Router } from "express";
import { all, get, insert, update, remove, createId } from "../data/db.js";
const router = Router();
function toApi(row) {
    const r = row;
    return {
        ...row,
        scope: r.scope === "api" ? "api" : "platform",
        variables: typeof r.variables === "string" ? JSON.parse(r.variables || "{}") : (r.variables || {}),
        accounts: typeof r.accounts === "string" ? JSON.parse(r.accounts || "[]") : (r.accounts || []),
    };
}
// GET /api/environments
router.get("/", (req, res) => {
    const scope = String(req.query.scope || "");
    let items = all("environments");
    if (scope === "api" || scope === "platform")
        items = items.filter((item) => (item.scope || "platform") === scope);
    res.json({ items: items.map(toApi) });
});
// POST /api/environments
router.post("/", (req, res) => {
    const { name } = req.body;
    if (!name) {
        res.status(400).json({ error: "name is required" });
        return;
    }
    const row = {
        id: createId(),
        name,
        url: req.body.url || "",
        type: req.body.type || "dev",
        scope: req.body.scope === "api" ? "api" : "platform",
        variables: JSON.stringify(req.body.variables || {}),
        accounts: JSON.stringify(req.body.accounts || []),
        status: req.body.status || "online",
    };
    insert("environments", row);
    res.status(201).json(toApi(row));
});
// GET /api/environments/:id
router.get("/:id", (req, res) => {
    const item = get("environments", req.params.id);
    if (!item) {
        res.status(404).json({ error: "not found" });
        return;
    }
    res.json(toApi(item));
});
// PUT /api/environments/:id
router.put("/:id", (req, res) => {
    const existing = get("environments", req.params.id);
    if (!existing) {
        res.status(404).json({ error: "not found" });
        return;
    }
    const data = {};
    if (req.body.name !== undefined)
        data.name = req.body.name;
    if (req.body.url !== undefined)
        data.url = req.body.url;
    if (req.body.type !== undefined)
        data.type = req.body.type;
    if (req.body.scope !== undefined)
        data.scope = req.body.scope === "api" ? "api" : "platform";
    if (req.body.variables !== undefined)
        data.variables = JSON.stringify(req.body.variables);
    if (req.body.accounts !== undefined)
        data.accounts = JSON.stringify(req.body.accounts);
    if (req.body.status !== undefined)
        data.status = req.body.status;
    update("environments", req.params.id, data);
    const updated = get("environments", req.params.id);
    res.json(toApi(updated || {}));
});
// DELETE /api/environments/:id
router.delete("/:id", (req, res) => {
    const ok = remove("environments", req.params.id);
    if (!ok) {
        res.status(404).json({ error: "not found" });
        return;
    }
    res.json({ ok: true });
});
export default router;
//# sourceMappingURL=environments.js.map