import { Router } from "express";
import { get, query, remove } from "../data/db.js";
import { CaseExecutionError, completeLocalCaseExecution } from "../case-execution.js";
import { safeLimit, safePage } from "../paging.js";
const router = Router();
// GET /api/executions
router.get("/", (req, res) => {
    const { status, caseId, page = "1", limit = "20" } = req.query;
    let list = query(`SELECT * FROM executions ORDER BY start_time DESC`);
    if (status)
        list = list.filter((e) => e.status === status);
    if (caseId)
        list = list.filter((e) => e.case_id === caseId || e.caseId === caseId);
    const p = safePage(page, 1);
    const l = safeLimit(limit, 20);
    const total = list.length;
    const items = list.slice((p - 1) * l, p * l).map(toApi);
    res.json({ items, total, page: p, limit: l });
});
// GET /api/executions/:id
router.get("/:id", (req, res) => {
    const item = get("executions", req.params.id);
    if (!item) {
        res.status(404).json({ error: "not found" });
        return;
    }
    res.json(toApi(item));
});
// DELETE /api/executions/:id
router.delete("/:id", (req, res) => {
    const ok = remove("executions", req.params.id);
    if (!ok) {
        res.status(404).json({ error: "not found" });
        return;
    }
    res.json({ ok: true });
});
// GET /api/executions/:id/logs
router.get("/:id/logs", (req, res) => {
    const item = get("executions", req.params.id);
    if (!item) {
        res.status(404).json({ error: "not found" });
        return;
    }
    res.json({ logs: item.logs });
});
// POST /api/executions/:id/verify — 本地执行器执行前校验任务令牌（防任意脚本提交）
router.post("/:id/verify", (req, res) => {
    const execution = get("executions", req.params.id);
    const token = String(req.body?.token || "");
    if (!execution) {
        res.status(404).json({ error: "执行记录不存在" });
        return;
    }
    if (!token || token !== execution.runner_token) {
        res.status(403).json({ error: "任务令牌无效" });
        return;
    }
    res.json({ ok: true, executionId: execution.id, caseName: execution.case_name });
});
// POST /api/executions/:id/local-result — 接收访问者本机执行器的结果
router.post("/:id/local-result", (req, res) => {
    try {
        const completed = completeLocalCaseExecution(req.params.id, String(req.body?.token || ""), req.body?.result, String(req.body?.runnerName || "本地执行器"));
        res.json(completed);
    }
    catch (error) {
        const status = error instanceof CaseExecutionError ? error.status : 500;
        res.status(status).json({ error: error instanceof Error ? error.message : "本地执行报告保存失败" });
    }
});
function toApi(row) {
    const { runner_token: _, ...publicRow } = row;
    return {
        ...publicRow,
        caseId: row.case_id,
        caseName: row.case_name,
        startTime: row.start_time,
        endTime: row.end_time,
        errorMessage: row.error_message,
    };
}
export default router;
//# sourceMappingURL=executions.js.map