import { Router } from "express";
import { all, get, insert, update, remove, exec, createId, now } from "../data/db.js";
import { runApiTest } from "../api-test-runner.js";
import { parsePostmanCollection } from "../postman-import.js";
import { listApiCollections, queueApiCollectionRun } from "../api-collection-runner.js";
const router = Router();
function parseJson(value, fallback) {
    if (typeof value !== "string")
        return value ?? fallback;
    try {
        return JSON.parse(value);
    }
    catch {
        return fallback;
    }
}
function toApiCase(row) {
    return {
        id: row.id,
        name: row.name,
        description: row.description || "",
        method: row.method || "GET",
        url: row.url || "",
        headers: parseJson(row.headers, []),
        queryParams: parseJson(row.query_params, []),
        bodyType: row.body_type || "none",
        body: row.body || "",
        assertions: parseJson(row.assertions, []),
        variables: parseJson(row.variables, {}),
        environmentId: row.environment_id || "",
        group: row.group_name || "",
        sortOrder: Number(row.sort_order) || 0,
        createdAt: row.created_at,
        updatedAt: row.updated_at,
    };
}
function toApiExecution(row) {
    return {
        id: row.id,
        caseId: row.case_id || "",
        caseName: row.case_name || "",
        status: row.status,
        method: row.method,
        url: row.url,
        statusCode: row.status_code,
        duration: row.duration || 0,
        responseSize: row.response_size || 0,
        requestHeaders: parseJson(row.request_headers, {}),
        requestBody: row.request_body || "",
        responseHeaders: parseJson(row.response_headers, {}),
        responseBody: row.response_body || "",
        assertionResults: parseJson(row.assertion_results, []),
        errorMessage: row.error_message || "",
        createdAt: row.created_at,
    };
}
function toApiCollectionRun(row) {
    return {
        id: row.id,
        collectionPath: row.collection_path,
        collectionName: row.collection_name,
        scheduleId: row.schedule_id || "",
        triggerType: row.trigger_type || "manual",
        environmentId: row.environment_id || "",
        status: row.status,
        total: Number(row.total) || 0,
        passed: Number(row.passed) || 0,
        failed: Number(row.failed) || 0,
        duration: Number(row.duration) || 0,
        items: parseJson(row.items, []),
        startedAt: row.started_at,
        endedAt: row.ended_at,
        createdAt: row.created_at,
    };
}
function caseRow(body, id = createId()) {
    const timestamp = now();
    return {
        id,
        name: String(body.name || "未命名接口"),
        description: String(body.description || ""),
        method: String(body.method || "GET").toUpperCase(),
        url: String(body.url || ""),
        headers: JSON.stringify(Array.isArray(body.headers) ? body.headers : []),
        query_params: JSON.stringify(Array.isArray(body.queryParams) ? body.queryParams : []),
        body_type: String(body.bodyType || "none"),
        body: String(body.body || ""),
        assertions: JSON.stringify(Array.isArray(body.assertions) ? body.assertions : []),
        variables: JSON.stringify(body.variables && typeof body.variables === "object" ? body.variables : {}),
        environment_id: String(body.environmentId || ""),
        group_name: String(body.group || ""),
        sort_order: Math.max(0, Number(body.sortOrder) || 0),
        created_at: timestamp,
        updated_at: timestamp,
    };
}
router.get("/cases", (req, res) => {
    const search = String(req.query.search || "").toLowerCase();
    const group = String(req.query.group || "");
    let items = all("api_cases");
    if (search)
        items = items.filter((item) => String(item.name).toLowerCase().includes(search) || String(item.url).toLowerCase().includes(search));
    if (group)
        items = items.filter((item) => item.group_name === group);
    items.sort((a, b) => {
        if (String(a.group_name || "") === String(b.group_name || "")) {
            const orderDifference = (Number(a.sort_order) || 0) - (Number(b.sort_order) || 0);
            if (orderDifference !== 0)
                return orderDifference;
        }
        return String(b.updated_at).localeCompare(String(a.updated_at));
    });
    res.json({ items: items.map(toApiCase), total: items.length });
});
router.post("/cases", (req, res) => {
    if (!String(req.body?.name || "").trim()) {
        res.status(400).json({ error: "用例名称不能为空" });
        return;
    }
    const row = caseRow(req.body);
    insert("api_cases", row);
    res.status(201).json(toApiCase(row));
});
router.post("/run", async (req, res) => {
    const result = await runApiTest(req.body || {});
    res.json(toApiExecution(result));
});
router.get("/collections", (_req, res) => {
    res.json({ items: listApiCollections() });
});
router.post("/collections/run", (req, res) => {
    try {
        const run = queueApiCollectionRun({
            collectionPath: String(req.body?.collectionPath || ""),
            environmentId: req.body?.environmentId ? String(req.body.environmentId) : undefined,
            triggerType: "manual",
        });
        res.status(202).json(toApiCollectionRun(run));
    }
    catch (error) {
        res.status(400).json({ error: error instanceof Error ? error.message : "集合执行失败" });
    }
});
router.get("/collection-runs", (req, res) => {
    const limit = Math.min(Math.max(Number(req.query.limit) || 50, 1), 100);
    const status = String(req.query.status || "");
    let items = all("api_collection_runs");
    if (status)
        items = items.filter((item) => item.status === status);
    items.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    res.json({ items: items.slice(0, limit).map(toApiCollectionRun), total: items.length });
});
router.get("/collection-runs/:id", (req, res) => {
    const run = get("api_collection_runs", req.params.id);
    if (!run) {
        res.status(404).json({ error: "集合报告不存在" });
        return;
    }
    res.json(toApiCollectionRun(run));
});
router.delete("/collection-runs/:id", (req, res) => {
    if (!remove("api_collection_runs", req.params.id)) {
        res.status(404).json({ error: "集合报告不存在" });
        return;
    }
    res.json({ ok: true });
});
router.post("/import/postman", (req, res) => {
    try {
        const document = req.body?.collection ?? req.body;
        const isEnvironment = document
            && typeof document === "object"
            && Array.isArray(document.values)
            && (document._postman_variable_scope === "environment" || !document.info);
        if (isEnvironment) {
            const values = document.values.filter((item) => item && String(item.key || "").trim());
            const enabledValues = values.filter((item) => item.enabled !== false);
            const variables = Object.fromEntries(enabledValues.map((item) => [String(item.key), String(item.value ?? "")]));
            const urlCandidate = enabledValues.find((item) => /^https?:\/\//i.test(String(item.value || ""))
                && /(?:url|host|gateway|base)/i.test(String(item.key || "")));
            const name = String(document.name || "Postman 环境").trim();
            const existing = all("environments").find((item) => String(item.name) === name);
            const environmentRow = {
                name,
                url: String(urlCandidate?.value || ""),
                type: existing?.type || "dev",
                scope: "api",
                variables: JSON.stringify(variables),
                accounts: JSON.stringify(existing?.accounts || []),
                status: existing?.status || "online",
            };
            let environmentId;
            if (existing) {
                environmentId = existing.id;
                update("environments", environmentId, environmentRow);
            }
            else {
                environmentId = createId();
                insert("environments", { id: environmentId, ...environmentRow });
            }
            res.status(existing ? 200 : 201).json({
                kind: "environment",
                environment: { id: environmentId, ...environmentRow, variables, accounts: existing?.accounts || [] },
                importedVariables: enabledValues.length,
                skippedVariables: values.length - enabledValues.length,
                updated: Boolean(existing),
                warnings: values.length === enabledValues.length ? [] : [`${values.length - enabledValues.length} 个已禁用变量未导入`],
            });
            return;
        }
        const parsed = parsePostmanCollection(document);
        const imported = [];
        exec("BEGIN");
        try {
            for (const definition of parsed.cases) {
                const row = caseRow(definition);
                insert("api_cases", row);
                imported.push(toApiCase(row));
            }
            exec("COMMIT");
        }
        catch (error) {
            exec("ROLLBACK");
            throw error;
        }
        res.status(201).json({
            kind: "collection",
            collectionName: parsed.collectionName,
            imported: imported.length,
            skipped: parsed.skipped,
            warnings: parsed.warnings,
            items: imported,
        });
    }
    catch (error) {
        res.status(400).json({ error: error instanceof Error ? error.message : "Postman Collection 导入失败" });
    }
});
router.get("/executions", (req, res) => {
    const caseId = String(req.query.caseId || "");
    const limit = Math.min(Math.max(Number(req.query.limit) || 20, 1), 100);
    let items = all("api_executions");
    if (caseId)
        items = items.filter((item) => item.case_id === caseId);
    items.sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)));
    res.json({ items: items.slice(0, limit).map(toApiExecution), total: items.length });
});
router.delete("/executions/:id", (req, res) => {
    if (!remove("api_executions", req.params.id)) {
        res.status(404).json({ error: "执行记录不存在" });
        return;
    }
    res.json({ ok: true });
});
router.get("/cases/:id", (req, res) => {
    const item = get("api_cases", req.params.id);
    if (!item) {
        res.status(404).json({ error: "接口用例不存在" });
        return;
    }
    res.json(toApiCase(item));
});
router.put("/cases/reorder", (req, res) => {
    const items = Array.isArray(req.body?.items) ? req.body.items : [];
    if (items.length === 0) {
        res.status(400).json({ error: "排序数据不能为空" });
        return;
    }
    if (items.some((item) => !String(item?.id || "").trim())) {
        res.status(400).json({ error: "排序数据缺少接口 ID" });
        return;
    }
    const missing = items.find((item) => !get("api_cases", String(item.id)));
    if (missing) {
        res.status(404).json({ error: `接口用例不存在: ${missing.id}` });
        return;
    }
    exec("BEGIN");
    try {
        for (const item of items) {
            update("api_cases", String(item.id), {
                group_name: String(item.group || ""),
                sort_order: Math.max(0, Number(item.sortOrder) || 0),
            });
        }
        exec("COMMIT");
        res.json({ ok: true });
    }
    catch (error) {
        exec("ROLLBACK");
        throw error;
    }
});
router.put("/cases/:id", (req, res) => {
    const existing = get("api_cases", req.params.id);
    if (!existing) {
        res.status(404).json({ error: "接口用例不存在" });
        return;
    }
    if (req.body.name !== undefined && !String(req.body.name).trim()) {
        res.status(400).json({ error: "用例名称不能为空" });
        return;
    }
    const full = caseRow({ ...toApiCase(existing), ...req.body }, req.params.id);
    const { id, created_at, ...changes } = full;
    changes.updated_at = now();
    update("api_cases", req.params.id, changes);
    res.json(toApiCase(get("api_cases", req.params.id) || {}));
});
router.delete("/cases/:id", (req, res) => {
    if (!remove("api_cases", req.params.id)) {
        res.status(404).json({ error: "接口用例不存在" });
        return;
    }
    exec("DELETE FROM api_executions WHERE case_id = ?", req.params.id);
    res.json({ ok: true });
});
export default router;
//# sourceMappingURL=api-tests.js.map