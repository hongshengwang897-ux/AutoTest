export declare function sendAlert(item: Record<string, any>, text: string): Promise<void>;
export declare function deliverExecutionAlerts(caseName: string, status: string, errorMessage?: string): Promise<void>;
