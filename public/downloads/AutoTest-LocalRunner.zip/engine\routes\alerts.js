import { Router } from "express";
import { all, get, insert, update, remove, createId } from "../data/db.js";
import { sendAlert } from "../alert-delivery.js";
const router = Router();
function toApi(row) {
    return {
        ...row,
        webhookUrl: row.webhook_url,
        notifyLevels: typeof row.notify_levels === "string" ? JSON.parse(row.notify_levels || "[]") : (row.notify_levels || []),
        enabled: !!row.enabled,
    };
}
// GET /api/alerts
router.get("/", (_req, res) => {
    res.json({ items: all("alerts").map(toApi) });
});
// POST /api/alerts
router.post("/", (req, res) => {
    const { name } = req.body;
    if (!name) {
        res.status(400).json({ error: "name is required" });
        return;
    }
    const row = {
        id: createId(),
        name,
        channel: req.body.channel || "dingtalk",
        webhook_url: req.body.webhookUrl || req.body.webhook_url || "",
        notify_levels: JSON.stringify(req.body.notifyLevels || req.body.notify_levels || []),
        template: req.body.template || "",
        enabled: req.body.enabled ? 1 : 0,
    };
    insert("alerts", row);
    res.status(201).json(toApi(row));
});
// PUT /api/alerts/:id
router.put("/:id", (req, res) => {
    const existing = get("alerts", req.params.id);
    if (!existing) {
        res.status(404).json({ error: "not found" });
        return;
    }
    const data = {};
    if (req.body.name !== undefined)
        data.name = req.body.name;
    if (req.body.channel !== undefined)
        data.channel = req.body.channel;
    if (req.body.webhookUrl !== undefined)
        data.webhook_url = req.body.webhookUrl;
    if (req.body.notifyLevels !== undefined)
        data.notify_levels = JSON.stringify(req.body.notifyLevels);
    if (req.body.template !== undefined)
        data.template = req.body.template;
    if (req.body.enabled !== undefined)
        data.enabled = req.body.enabled ? 1 : 0;
    update("alerts", req.params.id, data);
    const updated = get("alerts", req.params.id);
    res.json(toApi(updated || {}));
});
// POST /api/alerts/:id/test
router.post("/:id/test", async (req, res) => {
    const item = get("alerts", req.params.id);
    if (!item) {
        res.status(404).json({ error: "not found" });
        return;
    }
    const text = `【AutoTest 测试消息】告警通道「${item.name}」连接成功`;
    try {
        await sendAlert(item, text);
        res.json({ message: "测试消息已发送" });
    }
    catch (error) {
        res.status(502).json({ error: error instanceof Error ? error.message : "Webhook 请求失败" });
    }
});
// DELETE /api/alerts/:id
router.delete("/:id", (req, res) => {
    const ok = remove("alerts", req.params.id);
    if (!ok) {
        res.status(404).json({ error: "not found" });
        return;
    }
    res.json({ ok: true });
});
export default router;
//# sourceMappingURL=alerts.js.map