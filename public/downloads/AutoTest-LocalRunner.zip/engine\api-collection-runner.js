import { all, get, insert, update, createId, now } from "./data/db.js";
import { runApiTest } from "./api-test-runner.js";
function normalizedGroup(value) {
    return String(value || "未分组").split(/\s*\/\s*/).map((part) => part.trim()).filter(Boolean).join(" / ") || "未分组";
}
function collectionCaseRows(collectionPath) {
    const path = normalizedGroup(collectionPath);
    return all("api_cases")
        .filter((row) => {
        const group = normalizedGroup(row.group_name);
        return group === path || group.startsWith(`${path} / `);
    })
        .sort((a, b) => {
        const groupDifference = normalizedGroup(a.group_name).localeCompare(normalizedGroup(b.group_name), "zh-CN");
        return groupDifference || (Number(a.sort_order) || 0) - (Number(b.sort_order) || 0);
    });
}
export function listApiCollections() {
    const counts = new Map();
    for (const row of all("api_cases")) {
        const parts = normalizedGroup(row.group_name).split(" / ");
        for (let index = 1; index <= parts.length; index += 1) {
            const path = parts.slice(0, index).join(" / ");
            counts.set(path, (counts.get(path) || 0) + 1);
        }
    }
    return [...counts.entries()]
        .map(([path, total]) => ({ path, name: path.split(" / ").at(-1) || path, total }))
        .sort((a, b) => a.path.localeCompare(b.path, "zh-CN"));
}
function caseDefinition(row, environmentId) {
    return {
        id: String(row.id),
        name: String(row.name || "未命名接口"),
        method: String(row.method || "GET"),
        url: String(row.url || ""),
        headers: Array.isArray(row.headers) ? row.headers : [],
        queryParams: Array.isArray(row.query_params) ? row.query_params : [],
        bodyType: row.body_type || "none",
        body: String(row.body || ""),
        assertions: Array.isArray(row.assertions) ? row.assertions : [],
        variables: row.variables && typeof row.variables === "object" ? row.variables : {},
        environmentId: environmentId || String(row.environment_id || ""),
    };
}
function reportUrl(value) {
    const text = String(value || "");
    try {
        const url = new URL(text);
        for (const name of [...url.searchParams.keys()]) {
            if (/(?:token|secret|password|pass|key|auth|credential)/i.test(name))
                url.searchParams.set(name, "********");
        }
        return url.toString();
    }
    catch {
        return text;
    }
}
async function executeCollectionRun(runId, rows, environmentId) {
    const startedAt = Date.now();
    const items = [];
    try {
        for (const [index, row] of rows.entries()) {
            const result = await runApiTest(caseDefinition(row, environmentId));
            const assertionResults = Array.isArray(result.assertion_results) ? result.assertion_results : [];
            items.push({
                id: createId(),
                executionId: result.id,
                caseId: String(row.id),
                caseName: String(row.name || "未命名接口"),
                method: String(result.method || row.method || "GET"),
                url: reportUrl(result.url),
                status: result.status,
                statusCode: result.status_code,
                duration: Number(result.duration) || 0,
                assertionTotal: assertionResults.length,
                assertionPassed: assertionResults.filter((item) => item.passed).length,
                errorMessage: String(result.error_message || ""),
                sortOrder: index,
            });
            update("api_collection_runs", runId, { items: JSON.stringify(items) });
        }
        const passed = items.filter((item) => item.status === "success").length;
        const endedAt = now();
        update("api_collection_runs", runId, {
            status: passed === items.length ? "success" : "failed",
            passed,
            failed: items.length - passed,
            duration: Date.now() - startedAt,
            items: JSON.stringify(items),
            ended_at: endedAt,
        });
    }
    catch (error) {
        update("api_collection_runs", runId, {
            status: "failed",
            passed: items.filter((item) => item.status === "success").length,
            failed: rows.length - items.filter((item) => item.status === "success").length,
            duration: Date.now() - startedAt,
            items: JSON.stringify(items),
            ended_at: now(),
        });
        console.error("[API Collection]", error instanceof Error ? error.message : error);
    }
}
export function queueApiCollectionRun(options) {
    const collectionPath = normalizedGroup(options.collectionPath);
    const rows = collectionCaseRows(collectionPath);
    if (rows.length === 0)
        throw new Error("集合中没有可执行的接口用例");
    if (options.environmentId) {
        const environment = get("environments", options.environmentId);
        if (!environment)
            throw new Error("所选接口测试环境不存在");
        if ((environment.scope || "platform") !== "api")
            throw new Error("所选环境不是接口测试环境");
    }
    const id = createId();
    const timestamp = now();
    const row = {
        id,
        collection_path: collectionPath,
        collection_name: collectionPath.split(" / ").at(-1) || collectionPath,
        schedule_id: options.scheduleId || "",
        trigger_type: options.triggerType || "manual",
        environment_id: options.environmentId || "",
        status: "running",
        total: rows.length,
        passed: 0,
        failed: 0,
        duration: 0,
        items: JSON.stringify([]),
        started_at: timestamp,
        ended_at: null,
        created_at: timestamp,
    };
    insert("api_collection_runs", row);
    void executeCollectionRun(id, rows, options.environmentId || "");
    return { ...row, items: [] };
}
//# sourceMappingURL=api-collection-runner.js.map