import cron from "node-cron";
import { all, get, update, now } from "./data/db.js";
import { queueCaseExecution } from "./case-execution.js";
import { queueApiCollectionRun } from "./api-collection-runner.js";
const tasks = new Map();
function stopTask(id) {
    const task = tasks.get(id);
    if (task) {
        task.stop();
        task.destroy();
        tasks.delete(id);
    }
}
export function reloadSchedule(id) {
    stopTask(id);
    const schedule = get("schedules", id);
    if (!schedule || !schedule.enabled || !cron.validate(schedule.cron_expression))
        return;
    const task = cron.schedule(schedule.cron_expression, () => {
        const current = get("schedules", id);
        if (!current?.enabled)
            return;
        if (current.target_type === "api_collection") {
            try {
                queueApiCollectionRun({
                    collectionPath: String(current.collection_path || ""),
                    environmentId: current.environment_id || undefined,
                    scheduleId: id,
                    triggerType: "schedule",
                });
                update("schedules", id, { last_run_time: now() });
            }
            catch (error) {
                console.error(`[Scheduler] ${current.name}:`, error instanceof Error ? error.message : error);
            }
        }
        else {
            const caseIds = Array.isArray(current.case_ids) ? current.case_ids : [];
            let accepted = 0;
            for (const caseId of caseIds) {
                try {
                    queueCaseExecution(String(caseId), current.environment_id || undefined);
                    accepted++;
                }
                catch (error) {
                    console.error(`[Scheduler] ${current.name}:`, error instanceof Error ? error.message : error);
                }
            }
            // 至少成功入队一次才认为本次调度真实执行过，避免“假运行”
            if (accepted > 0)
                update("schedules", id, { last_run_time: now() });
        }
        // 触发后重新计算并持久化下次运行时间
        refreshNextRunTime(id);
    });
    tasks.set(id, task);
    refreshNextRunTime(id);
}
/** 计算并持久化 next_run_time（使用 node-cron 内部下一次触发时间） */
export function refreshNextRunTime(id) {
    try {
        const task = tasks.get(id);
        const schedule = get("schedules", id);
        if (!task || !schedule?.enabled) {
            update("schedules", id, { next_run_time: null });
            return;
        }
        const ms = task.msToNext();
        if (typeof ms === "number" && Number.isFinite(ms) && ms > 0) {
            update("schedules", id, { next_run_time: new Date(Date.now() + ms).toISOString() });
        }
    }
    catch (error) {
        console.error("[Scheduler] 计算 next_run_time 失败:", error instanceof Error ? error.message : error);
    }
}
export function computeNextRunTime(id) {
    try {
        const task = tasks.get(id);
        if (!task)
            return null;
        const ms = task.msToNext();
        return typeof ms === "number" && Number.isFinite(ms) && ms > 0
            ? new Date(Date.now() + ms).toISOString()
            : null;
    }
    catch {
        return null;
    }
}
export function removeScheduleTask(id) {
    stopTask(id);
}
export function initializeScheduler() {
    for (const id of [...tasks.keys()])
        stopTask(id);
    for (const schedule of all("schedules"))
        reloadSchedule(String(schedule.id));
    console.log(`[Scheduler] 已注册 ${tasks.size} 个定时任务`);
}
export function shutdownScheduler() {
    for (const id of [...tasks.keys()])
        stopTask(id);
}
export function isValidCron(expression) {
    return cron.validate(expression);
}
//# sourceMappingURL=scheduler.js.map